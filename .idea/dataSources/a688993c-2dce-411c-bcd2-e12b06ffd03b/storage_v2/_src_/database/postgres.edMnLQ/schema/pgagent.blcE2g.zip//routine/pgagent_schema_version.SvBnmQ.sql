create function pgagent_schema_version() returns smallint
    language plpgsql
as
$$
BEGIN
    -- RETURNS PGAGENT MAJOR VERSION
    -- WE WILL CHANGE THE MAJOR VERSION, ONLY IF THERE IS A SCHEMA CHANGE
    RETURN 4;
END;
$$;

alter function pgagent_schema_version() owner to postgres;

